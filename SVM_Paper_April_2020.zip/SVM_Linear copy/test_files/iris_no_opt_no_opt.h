#define COEFICIENTS_OPTMIZATION "NONE" 
#define VECTORS_OPTMIZATION "NONE" 
#define N_FEATURES 4   
#define N_VECTORS 23    
#define N_INTERCEPTS 3 
#define N_ROWS 3       
#define N_CLASSES 3    
#define N_COEFICIENTS 2 


double intercepts[N_INTERCEPTS] = {1.4528444969775751,1.289329940293088,5.3720694409233305};
double coeficients[N_COEFICIENTS][23] = {{0.07709756347590406,0.670752890310352,0.0,-0.0,-0.0,-0.0,-0.0,-0.0,-0.0,-0.0,-0.0,-0.0,-0.0,-0.747850453786256,-0.0,-0.0,-0.0,-0.0,-0.0,-0.20090783087901554,-0.0,-0.0,-0.0},{0.0,0.17400541377830372,0.02690241710071183,1.0,0.8290419989475597,1.0,1.0,0.4311586938448126,1.0,1.0,0.5555717250187097,1.0,1.0,0.0,-1.0,-1.0,-1.0,-1.0,-0.8157724178110821,-1.0,-1.0,-1.0,-1.0}};

double vectors[N_VECTORS][N_FEATURES] = {{4.5,2.3,1.3,0.3},{5.1,3.3,1.7,0.5},{5.1,3.8,1.9,0.4},{6.2,2.2,4.5,1.5},{6.0,3.4,4.5,1.6},{6.7,3.0,5.0,1.7},{6.0,2.7,5.1,1.6},{6.9,3.1,4.9,1.5},{6.1,2.9,4.7,1.4},{6.3,3.3,4.7,1.6},{5.5,2.6,4.4,1.2},{5.7,2.8,4.5,1.3},{6.0,2.9,4.5,1.5},{5.1,2.5,3.0,1.1},{6.3,2.7,4.9,1.8},{6.5,3.2,5.1,2.0},{6.3,2.8,5.1,1.5},{6.0,3.0,4.8,1.8},{5.9,3.0,5.1,1.8},{4.9,2.5,4.5,1.7},{6.2,2.8,4.8,1.8},{6.0,2.2,5.0,1.5},{6.1,3.0,4.9,1.8}};

unsigned char range[] = {0,3,14,23};
int predict (double features[]){
	int i, j, d, l, t, k;
	double kernels[N_VECTORS], kernel=0, tmp=0;
	int amounts[N_CLASSES];
	
        for (i = 0; i < N_VECTORS; i++){
	
            kernel = 0.;
	
            for (j = 0; j < N_FEATURES; j++) {
	
	
                kernel += vectors[i][j] * features[j];
	
            }
	
            kernels[i] = kernel;

        }



    for (i = 0, l = N_CLASSES; i < l; i++) {
        amounts[i] = 0; // Guarantees everything is clear
    }

    for (i = 0, d = 0, l = N_ROWS; i < l; i++) {
        for (j = i + 1; j < l; j++) {
            tmp = 0.;
            
        for (k = range[j]; k < range[j+1]; k++){
	
            tmp += kernels[k] * coeficients[i][k];

        }

        for (k = range[i]; k < range[i+1]; k++){
	
            tmp += kernels[k] * coeficients[j - 1][k];

        }

        
            if(tmp + intercepts[d] > 0){
                amounts[i] += 1;
            }
            else{
                amounts[j] += 1;
            }
            d = d + 1;
        }
    }

    int classVal = -1;
    int classIdx = -1;
    for (i = 0; i < N_CLASSES; i++) {
        if (amounts[i] > classVal) {
            classVal = amounts[i];
            classIdx= i;
        }
    }
    return classIdx;

}


        