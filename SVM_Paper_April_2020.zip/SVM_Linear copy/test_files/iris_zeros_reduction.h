#define COEFICIENTS_OPTMIZATION "REDUCTION" 
#define VECTORS_OPTMIZATION "ZEROS" 
#define N_FEATURES 4   
#define N_VECTORS 23    
#define N_INTERCEPTS 3 
#define N_ROWS 3       
#define N_CLASSES 3    
#define N_COEFICIENTS 2 


double intercepts[N_INTERCEPTS] = {1.4528444969775751,1.289329940293088,5.3720694409233305};
unsigned char coefs_idx_0[] = {0,1,13,0};double coefs_0[] = {0.07709756347590406,0.670752890310352,-0.747850453786256,0.0};unsigned char coefs_idx_1[] = {1,2,19,0};double coefs_1[] = {0.17400541377830372,0.02690241710071183,-0.20090783087901554,0.0};unsigned char coefs_idx_2[] = {3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,0};double coefs_2[] = {1.0,0.8290419989475597,1.0,1.0,0.4311586938448126,1.0,1.0,0.5555717250187097,1.0,1.0,-1.0,-1.0,-1.0,-1.0,-0.8157724178110821,-1.0,-1.0,-1.0,-1.0,0.0};double * coefs[] = {coefs_0,coefs_1,coefs_2};unsigned char * coefs_idx[] = {coefs_idx_0,coefs_idx_1,coefs_idx_2};
unsigned char non_zero_0[] = {0,1,2,3,255};
double vectors_0[] = {4.5,2.3,1.3,0.3};
unsigned char non_zero_1[] = {0,1,2,3,255};
double vectors_1[] = {5.1,3.3,1.7,0.5};
unsigned char non_zero_2[] = {0,1,2,3,255};
double vectors_2[] = {5.1,3.8,1.9,0.4};
unsigned char non_zero_3[] = {0,1,2,3,255};
double vectors_3[] = {6.2,2.2,4.5,1.5};
unsigned char non_zero_4[] = {0,1,2,3,255};
double vectors_4[] = {6.0,3.4,4.5,1.6};
unsigned char non_zero_5[] = {0,1,2,3,255};
double vectors_5[] = {6.7,3.0,5.0,1.7};
unsigned char non_zero_6[] = {0,1,2,3,255};
double vectors_6[] = {6.0,2.7,5.1,1.6};
unsigned char non_zero_7[] = {0,1,2,3,255};
double vectors_7[] = {6.9,3.1,4.9,1.5};
unsigned char non_zero_8[] = {0,1,2,3,255};
double vectors_8[] = {6.1,2.9,4.7,1.4};
unsigned char non_zero_9[] = {0,1,2,3,255};
double vectors_9[] = {6.3,3.3,4.7,1.6};
unsigned char non_zero_10[] = {0,1,2,3,255};
double vectors_10[] = {5.5,2.6,4.4,1.2};
unsigned char non_zero_11[] = {0,1,2,3,255};
double vectors_11[] = {5.7,2.8,4.5,1.3};
unsigned char non_zero_12[] = {0,1,2,3,255};
double vectors_12[] = {6.0,2.9,4.5,1.5};
unsigned char non_zero_13[] = {0,1,2,3,255};
double vectors_13[] = {5.1,2.5,3.0,1.1};
unsigned char non_zero_14[] = {0,1,2,3,255};
double vectors_14[] = {6.3,2.7,4.9,1.8};
unsigned char non_zero_15[] = {0,1,2,3,255};
double vectors_15[] = {6.5,3.2,5.1,2.0};
unsigned char non_zero_16[] = {0,1,2,3,255};
double vectors_16[] = {6.3,2.8,5.1,1.5};
unsigned char non_zero_17[] = {0,1,2,3,255};
double vectors_17[] = {6.0,3.0,4.8,1.8};
unsigned char non_zero_18[] = {0,1,2,3,255};
double vectors_18[] = {5.9,3.0,5.1,1.8};
unsigned char non_zero_19[] = {0,1,2,3,255};
double vectors_19[] = {4.9,2.5,4.5,1.7};
unsigned char non_zero_20[] = {0,1,2,3,255};
double vectors_20[] = {6.2,2.8,4.8,1.8};
unsigned char non_zero_21[] = {0,1,2,3,255};
double vectors_21[] = {6.0,2.2,5.0,1.5};
unsigned char non_zero_22[] = {0,1,2,3,255};
double vectors_22[] = {6.1,3.0,4.9,1.8};
double * vectors[] = {vectors_0,vectors_1,vectors_2,vectors_3,vectors_4,vectors_5,vectors_6,vectors_7,vectors_8,vectors_9,vectors_10,vectors_11,vectors_12,vectors_13,vectors_14,vectors_15,vectors_16,vectors_17,vectors_18,vectors_19,vectors_20,vectors_21,vectors_22};
unsigned char * non_zeros[] = {non_zero_0,non_zero_1,non_zero_2,non_zero_3,non_zero_4,non_zero_5,non_zero_6,non_zero_7,non_zero_8,non_zero_9,non_zero_10,non_zero_11,non_zero_12,non_zero_13,non_zero_14,non_zero_15,non_zero_16,non_zero_17,non_zero_18,non_zero_19,non_zero_20,non_zero_21,non_zero_22};

unsigned char range[] = {0,3,14,23};
int predict (double features[]){
	int i, j, d, l, t, k;
	double kernels[N_VECTORS], kernel=0, tmp=0;
	int amounts[N_CLASSES];
	
                for (i=0; i< N_VECTORS; i++){
	
                    kernel = 0;
	
                    j = 0;
	
                    while(non_zeros[i][j] != 255){
		
                        kernel += vectors[i][j] * features[non_zeros[i][j]];
		
                        j++;
	
                    }
	
                    kernels[i] = kernel;

                }

                


    for (i = 0, l = N_CLASSES; i < l; i++) {
        amounts[i] = 0; // Guarantees everything is clear
    }

    for (i = 0, d = 0, l = N_ROWS; i < l; i++) {
        for (j = i + 1; j < l; j++) {
            tmp = 0.;
            
        k = 0;
        while(coefs[d][k] != 0){
            tmp += kernels[coefs_idx[d][k]] * coefs[d][k];
            k++;
        }
        
            if(tmp + intercepts[d] > 0){
                amounts[i] += 1;
            }
            else{
                amounts[j] += 1;
            }
            d = d + 1;
        }
    }

    int classVal = -1;
    int classIdx = -1;
    for (i = 0; i < N_CLASSES; i++) {
        if (amounts[i] > classVal) {
            classVal = amounts[i];
            classIdx= i;
        }
    }
    return classIdx;

}


        