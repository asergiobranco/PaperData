#define COEFICIENTS_OPTMIZATION "ZEROS" 
#define VECTORS_OPTMIZATION "ZEROS" 
#define N_FEATURES 13   
#define N_VECTORS 23    
#define N_INTERCEPTS 3 
#define N_ROWS 3       
#define N_CLASSES 3    
#define N_COEFICIENTS 2 


double intercepts[N_INTERCEPTS] = {-18.76215284661188,-4.149800859121906,22.454460931957083};
double coeficient_0[] = {0.4176481617618602,1.0,0.7436010718110455,-0.255057331542612,-0.7216770064393694,-0.11085998094615603,-0.01602934409742398,-1.0,-0.057625570547358555,-0.13950298634830827,-0.004800166612587793,-0.014573354936159851,-0.11176414377958765}; 
double coeficient_1[] = {0.15472672734493725,0.02115665760795751,0.09475726672374925,0.3032552748048841,0.012185346661463509,0.5134073772320232,0.5802300852916376,0.9329742340238475,-0.8056859082912073,-0.397574494127368,-0.11441377984077124,-0.024378135754495475,-1.0}; 
unsigned char coeficient_idx_0[] = {0,2,3,5,7,8,10,13,14,15,17,20,22,255}; 
unsigned char coeficient_idx_1[] = {0,1,4,6,7,9,11,12,16,18,19,21,22,255}; 
double * coeficients[N_COEFICIENTS] = {coeficient_0,coeficient_1}; 
unsigned char * coeficients_idx[N_COEFICIENTS] = {coeficient_idx_0,coeficient_idx_1}; 

unsigned char non_zero_0[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_0[] = {13.24,2.59,2.87,21.0,118.0,2.8,2.69,0.39,1.82,4.32,1.04,2.93,735.0};
unsigned char non_zero_1[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_1[] = {13.05,1.65,2.55,18.0,98.0,2.45,2.43,0.29,1.44,4.25,1.12,2.51,1105.0};
unsigned char non_zero_2[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_2[] = {13.05,2.05,3.22,25.0,124.0,2.63,2.68,0.47,1.92,3.58,1.13,3.2,830.0};
unsigned char non_zero_3[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_3[] = {13.5,1.81,2.61,20.0,96.0,2.53,2.61,0.28,1.66,3.52,1.12,3.82,845.0};
unsigned char non_zero_4[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_4[] = {13.24,3.98,2.29,17.5,103.0,2.64,2.63,0.32,1.66,4.36,0.82,3.0,680.0};
unsigned char non_zero_5[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_5[] = {12.47,1.52,2.2,19.0,162.0,2.5,2.27,0.32,3.28,2.6,1.16,2.63,937.0};
unsigned char non_zero_6[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_6[] = {13.05,3.86,2.32,22.5,85.0,1.65,1.59,0.61,1.62,4.8,0.84,2.01,515.0};
unsigned char non_zero_7[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_7[] = {12.99,1.67,2.6,30.0,139.0,3.3,2.89,0.21,1.96,3.35,1.31,3.5,985.0};
unsigned char non_zero_8[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_8[] = {13.67,1.25,1.92,18.0,94.0,2.1,1.79,0.32,0.73,3.8,1.23,2.46,630.0};
unsigned char non_zero_9[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_9[] = {12.29,1.61,2.21,20.4,103.0,1.1,1.02,0.37,1.46,3.05,0.906,1.82,870.0};
unsigned char non_zero_10[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_10[] = {11.76,2.68,2.92,20.0,103.0,1.75,2.03,0.6,1.05,3.8,1.23,2.5,607.0};
unsigned char non_zero_11[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_11[] = {11.81,2.12,2.74,21.5,134.0,1.6,0.99,0.14,1.56,2.5,0.95,2.26,625.0};
unsigned char non_zero_12[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_12[] = {12.64,1.36,2.02,16.8,100.0,2.02,1.41,0.53,0.62,5.75,0.98,1.59,450.0};
unsigned char non_zero_13[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_13[] = {12.72,1.81,2.2,18.8,86.0,2.2,2.53,0.26,1.77,3.9,1.16,3.14,714.0};
unsigned char non_zero_14[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_14[] = {13.05,5.8,2.13,21.5,86.0,2.62,2.65,0.3,2.01,2.6,0.73,3.1,380.0};
unsigned char non_zero_15[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_15[] = {13.16,3.57,2.15,21.0,102.0,1.5,0.55,0.43,1.3,4.0,0.6,1.68,830.0};
unsigned char non_zero_16[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_16[] = {12.93,2.81,2.7,21.0,96.0,1.54,0.5,0.53,0.75,4.6,0.77,2.31,600.0};
unsigned char non_zero_17[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_17[] = {14.34,1.68,2.7,25.0,98.0,2.8,1.31,0.53,2.7,13.0,0.57,1.96,660.0};
unsigned char non_zero_18[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_18[] = {12.2,3.03,2.32,19.0,96.0,1.25,0.49,0.4,0.73,5.5,0.66,1.83,510.0};
unsigned char non_zero_19[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_19[] = {12.84,2.96,2.61,24.0,101.0,2.32,0.6,0.53,0.81,4.92,0.89,2.15,590.0};
unsigned char non_zero_20[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_20[] = {13.27,4.28,2.26,20.0,120.0,1.59,0.69,0.43,1.35,10.2,0.59,1.56,835.0};
unsigned char non_zero_21[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_21[] = {12.81,2.31,2.4,24.0,98.0,1.15,1.09,0.27,0.83,5.7,0.66,1.36,560.0};
unsigned char non_zero_22[] = {0,1,2,3,4,5,6,7,8,9,10,11,12,255};
double vectors_22[] = {12.86,1.35,2.32,18.0,122.0,1.51,1.25,0.21,0.94,4.1,0.76,1.29,630.0};
double * vectors[] = {vectors_0,vectors_1,vectors_2,vectors_3,vectors_4,vectors_5,vectors_6,vectors_7,vectors_8,vectors_9,vectors_10,vectors_11,vectors_12,vectors_13,vectors_14,vectors_15,vectors_16,vectors_17,vectors_18,vectors_19,vectors_20,vectors_21,vectors_22};
unsigned char * non_zeros[] = {non_zero_0,non_zero_1,non_zero_2,non_zero_3,non_zero_4,non_zero_5,non_zero_6,non_zero_7,non_zero_8,non_zero_9,non_zero_10,non_zero_11,non_zero_12,non_zero_13,non_zero_14,non_zero_15,non_zero_16,non_zero_17,non_zero_18,non_zero_19,non_zero_20,non_zero_21,non_zero_22};

unsigned char range[] = {0,5,15,23};
int predict (double features[]){
	int i, j, d, l, t, k;
	double kernels[N_VECTORS], kernel=0, tmp=0;
	int amounts[N_CLASSES];
	
                for (i=0; i< N_VECTORS; i++){
	
                    kernel = 0;
	
                    j = 0;
	
                    while(non_zeros[i][j] != 255){
		
                        kernel += vectors[i][j] * features[non_zeros[i][j]];
		
                        j++;
	
                    }
	
                    kernels[i] = kernel;

                }

                


    for (i = 0, l = N_CLASSES; i < l; i++) {
        amounts[i] = 0; // Guarantees everything is clear
    }

    for (i = 0, d = 0, l = N_ROWS; i < l; i++) {
        for (j = i + 1; j < l; j++) {
            tmp = 0.;
            
            t = 0;

            while(coeficients_idx[i][t] < range[j]){
	
                t++;

            }

            while(coeficients_idx[i][t] < range[j+1] && coeficients_idx[i][t] != 255){
	
                tmp += kernels[coeficients_idx[i][t]] * coeficients[i][t];
	
                t++;

            }

            t=0;

            while(coeficients_idx[j-1][t] < range[i]){
	
                t++;

            }

            while(coeficients_idx[j-1][t] < range[i+1] && coeficients_idx[j-1][t] != 255){
	
                tmp += kernels[coeficients_idx[j-1][t]] * coeficients[j-1][t];
	
                t++;

            }

        
            if(tmp + intercepts[d] > 0){
                amounts[i] += 1;
            }
            else{
                amounts[j] += 1;
            }
            d = d + 1;
        }
    }

    int classVal = -1;
    int classIdx = -1;
    for (i = 0; i < N_CLASSES; i++) {
        if (amounts[i] > classVal) {
            classVal = amounts[i];
            classIdx= i;
        }
    }
    return classIdx;

}


        