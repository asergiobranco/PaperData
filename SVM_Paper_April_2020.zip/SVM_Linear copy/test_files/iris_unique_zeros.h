#define COEFICIENTS_OPTMIZATION "ZEROS" 
#define VECTORS_OPTMIZATION "UNIQUE" 
#define N_FEATURES 4   
#define N_VECTORS 23    
#define N_INTERCEPTS 3 
#define N_ROWS 3       
#define N_CLASSES 3    
#define N_COEFICIENTS 2 


double intercepts[N_INTERCEPTS] = {1.4528444969775751,1.289329940293088,5.3720694409233305};
double coeficient_0[] = {0.07709756347590406,0.670752890310352,-0.747850453786256,-0.20090783087901554}; 
double coeficient_1[] = {0.17400541377830372,0.02690241710071183,1.0,0.8290419989475597,1.0,1.0,0.4311586938448126,1.0,1.0,0.5555717250187097,1.0,1.0,-1.0,-1.0,-1.0,-1.0,-0.8157724178110821,-1.0,-1.0,-1.0,-1.0}; 
unsigned char coeficient_idx_0[] = {0,1,13,19,255}; 
unsigned char coeficient_idx_1[] = {1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,255}; 
double * coeficients[N_COEFICIENTS] = {coeficient_0,coeficient_1}; 
unsigned char * coeficients_idx[N_COEFICIENTS] = {coeficient_idx_0,coeficient_idx_1}; 

double vectors[] = {0.3,0.4,0.5,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0,2.2,2.3,2.5,2.6,2.7,2.8,2.9,3.0,3.1,3.2,3.3,3.4,3.8,4.4,4.5,4.7,4.8,4.9,5.0,5.1,5.5,5.7,5.9,6.0,6.1,6.2,6.3,6.5,6.7,6.9};unsigned char vectors_idx[N_VECTORS][N_FEATURES] = {{27,14,5,0},{32,23,9,2},{32,25,11,1},{38,13,27,7},{36,24,27,8},{41,20,31,9},{36,17,32,8},{42,21,30,7},{37,19,28,6},{39,23,28,8},{33,16,26,4},{34,18,27,5},{36,19,27,7},{32,15,20,3},{39,17,30,10},{40,22,32,12},{39,18,32,7},{36,20,29,10},{35,20,32,10},{30,15,27,9},{38,18,29,10},{36,13,31,7},{37,20,30,10}};
unsigned char range[] = {0,3,14,23};
int predict (double features[]){
	int i, j, d, l, t, k;
	double kernels[N_VECTORS], kernel=0, tmp=0;
	int amounts[N_CLASSES];
	
        for (i = 0; i < N_VECTORS; i++){
	
            kernel = 0.;
	
            for (j = 0; j < N_FEATURES; j++) {
	
	
                kernel += vectors[vectors_idx[i][j]] * features[j];
	
            }
	
            kernels[i] = kernel;

        }

        


    for (i = 0, l = N_CLASSES; i < l; i++) {
        amounts[i] = 0; // Guarantees everything is clear
    }

    for (i = 0, d = 0, l = N_ROWS; i < l; i++) {
        for (j = i + 1; j < l; j++) {
            tmp = 0.;
            
            t = 0;

            while(coeficients_idx[i][t] < range[j]){
	
                t++;

            }

            while(coeficients_idx[i][t] < range[j+1] && coeficients_idx[i][t] != 255){
	
                tmp += kernels[coeficients_idx[i][t]] * coeficients[i][t];
	
                t++;

            }

            t=0;

            while(coeficients_idx[j-1][t] < range[i]){
	
                t++;

            }

            while(coeficients_idx[j-1][t] < range[i+1] && coeficients_idx[j-1][t] != 255){
	
                tmp += kernels[coeficients_idx[j-1][t]] * coeficients[j-1][t];
	
                t++;

            }

        
            if(tmp + intercepts[d] > 0){
                amounts[i] += 1;
            }
            else{
                amounts[j] += 1;
            }
            d = d + 1;
        }
    }

    int classVal = -1;
    int classIdx = -1;
    for (i = 0; i < N_CLASSES; i++) {
        if (amounts[i] > classVal) {
            classVal = amounts[i];
            classIdx= i;
        }
    }
    return classIdx;

}


        